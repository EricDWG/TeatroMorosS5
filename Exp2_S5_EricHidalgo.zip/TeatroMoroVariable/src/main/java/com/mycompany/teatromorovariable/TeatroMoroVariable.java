/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.teatromorovariable;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Eric Hidalgo S5
 */
public class TeatroMoroVariable {
    static String nombreTeatro = "Teatro Moro";
    static int entradasDisponibles = 100;
    static double precioBase = 10000;
    static int totalEntradasVendidas = 0;

    static ArrayList<String> entradas = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("---- MENU PRINCIPAL ----");
            System.out.println("1. Venta de entradas");
            System.out.println("2. Promociones");
            System.out.println("3. Buscar entrada");
            System.out.println("4. Eliminar entrada");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    venderEntrada(scanner);
                    break;
                case 2:
                    mostrarPromociones();
                    break;
                case 3:
                    buscarEntrada(scanner);
                    break;
                case 4:
                    eliminarEntrada(scanner);
                    break;
                default:
                    break;
            }

        } while (opcion != 5);

        System.out.println("Gracias por usar el sistema de " + nombreTeatro);
    }

    static void venderEntrada(Scanner scanner) {
        if (entradasDisponibles <= 0) {
            System.out.println("No hay entradas disponibles.");
            return;
        }

        System.out.print("Ingrese ubicacion (VIP, Platea, General): ");
        String ubicacion = scanner.next();

        System.out.print("Ingrese su edad: ");
        int edad = scanner.nextInt();

        double descuento = 0;
        if (edad < 25) {
            descuento = 0.10;
        } else if (edad >= 60) {
            descuento = 0.15;
        }

        double precioFinal = precioBase - (precioBase * descuento);
        entradasDisponibles--;
        totalEntradasVendidas++;

        String entrada = "N°" + totalEntradasVendidas + " - " + ubicacion + " - $" + precioFinal;
        entradas.add(entrada);

        System.out.println("Entrada vendida: " + entrada);
    }

    static void mostrarPromociones() {
        System.out.println("---- PROMOCIONES ----");
        System.out.println("Descuento del 10% para menores de 25 anos (estudiantes)");
        System.out.println("Descuento del 15% para mayores de 60 anos");
        System.out.println("Compra 3 entradas y paga solo 2 (solo en boleteria)");
    }

    static void buscarEntrada(Scanner scanner) {
        System.out.print("Ingrese numero de entrada a buscar: ");
        int numero = scanner.nextInt();

        for (String entrada : entradas) {
            if (entrada.contains("N°" + numero)) {
                System.out.println("Entrada encontrada: " + entrada);
                return;
            }
        }

        System.out.println("No se encontro la entrada.");
    }

    static void eliminarEntrada(Scanner scanner) {
        System.out.print("Ingrese numero de entrada a eliminar: ");
        int numero = scanner.nextInt();

        for (int i = 0; i < entradas.size(); i++) {
            if (entradas.get(i).contains("N°" + numero)) {
                entradas.remove(i);
                entradasDisponibles++;
                System.out.println("Entrada eliminada.");
                return;
            }
        }

        System.out.println("No se encontro la entrada.");
    }
}
